package com.fdmgroup.bankDesignProject;

public class Company extends Customer {

	private double balance;

	public Company(String name, String address) {
		super(name, address);

	}

	@Override
	public void chargeAllAccounts(double amount) {
		for (Account account : getAccounts()) {
			account.balance -= (amount * 2);
			}
		}

	}


