package com.fdmgroup.bankDesignProject;

public class SavingsAccount extends Account {
	private double interestRate;

	public void addInterest() {
		balance += getBalance() * (this.interestRate / 100);
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double rate) {
		this.interestRate = rate;
	}
	
	public double withdraw(double amount) {
		if(balance >= amount) {
		balance -= amount;
		return amount;
		}
		return 0;
		
	}
}
