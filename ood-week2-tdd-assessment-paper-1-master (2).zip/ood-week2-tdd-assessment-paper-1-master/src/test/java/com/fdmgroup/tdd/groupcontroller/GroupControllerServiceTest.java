package com.fdmgroup.tdd.groupcontroller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.function.BooleanSupplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GroupControllerServiceTest {
	private DatabaseReader mockReader;
	private DatabaseWriter mockWriter;
	private Trainee mockTrainee;
	GroupController Controller;

	@BeforeEach
	void setup() throws Exception {
		mockReader = mock(DatabaseReader.class);
		mockWriter = mock(DatabaseWriter.class);
		mockTrainee = mock(Trainee.class);
		Controller = new GroupController(mockReader, mockWriter);
	}

	@Test
	void test_1ToGetAll_TheTraineess() {
		Controller.getAllTrainees();
		verify(mockReader, times(1)).readGroup();
	}

	@Test
	void test_2WhenTraineeRemovedByUsername() {
		String userName = "1lee2Tania";
		Controller.removeTraineeByUsername(userName);
		verify(mockWriter, times(4)).deleteTraineeByUsername(userName);
	}

	@Test
	void test_WhenTraineeAdded() {
		Controller.addTrainee(mockTrainee);
		verify(mockWriter, times(6)).addTrainee(mockTrainee);
	}

}
