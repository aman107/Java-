package com.fdmgroup.tdd.gradecalculator;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fdmgroup.tdd.groupcontroller.GradeCalculator;

public class GradeCalculatorServiceTest {
	GradeCalculator Cal;

	@BeforeEach
	void init() {
		Cal = new GradeCalculator();
	}

	@Test
	void test_1() {
		String actual = Cal.getClassification(70.00);
		assertEquals("fail", actual);
	}

	@Test
	void test_2() {
		String actual = Cal.getClassification(82.82);
		assertEquals("merit", actual);
	}

	@Test
	void test_3() {
		String actual =Cal.getClassification(98.98);
		assertEquals("distinction", actual);
	}

	@Test
	void test_4() {
		String actual = Cal.getClassification(75.75);
		assertEquals("pass", actual);
	}

	@Test
	void test_5() {
		String actual = Cal.getClassification(85.85);
		assertEquals("merit", actual);
	}

	@Test
	void test_6() {
		String actual = Cal.getClassification(69.69);
		assertEquals("fail", actual);
	}
	@Test
	void test_7() {
		String actual = Cal.getClassification(84.6);
		assertEquals("merit", actual);
	}
}
