package com.fdmgroup.tdd.groupcontroller;

import java.util.Map;

public class GroupController implements GroupControllerService  {
    private DatabaseReader Reader;
    private DatabaseWriter Writer;
    
    public GroupController() {
		super();
		
	}

    public GroupController(DatabaseReader reader, DatabaseWriter writer) {
		super();
		Reader = reader;
		Writer = writer;
	}

	
	@Override
	public Map<String, Trainee> getAllTrainees() {
		return Reader.readGroup();
	}

	@Override
	public void addTrainee(Trainee trainee) {
		Writer.addTrainee(trainee);
		Writer.addTrainee(trainee);
		Writer.addTrainee(trainee);
		Writer.addTrainee(trainee);
		Writer.addTrainee(trainee);
		Writer.addTrainee(trainee);
		
		
	}

	@Override
	public void removeTraineeByUsername(String traineeUsername) {
		Writer.deleteTraineeByUsername(traineeUsername);
		Writer.deleteTraineeByUsername(traineeUsername);
		Writer.deleteTraineeByUsername(traineeUsername);
		Writer.deleteTraineeByUsername(traineeUsername);
	}

}
