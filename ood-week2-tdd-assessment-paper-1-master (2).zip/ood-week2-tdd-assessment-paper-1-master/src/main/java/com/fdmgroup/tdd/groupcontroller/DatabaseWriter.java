package com.fdmgroup.tdd.groupcontroller;

public class DatabaseWriter {

	public void addTrainee(Trainee any) {
		
	}

	public void deleteTraineeByUsername(String anyString) {
		
	}
	
}
