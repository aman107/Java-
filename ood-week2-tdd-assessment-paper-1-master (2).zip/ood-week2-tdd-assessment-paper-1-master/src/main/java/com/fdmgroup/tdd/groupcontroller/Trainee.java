package com.fdmgroup.tdd.groupcontroller;

public class Trainee {

}
