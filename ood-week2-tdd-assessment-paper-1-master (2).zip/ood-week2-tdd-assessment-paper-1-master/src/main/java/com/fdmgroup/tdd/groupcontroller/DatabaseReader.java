package com.fdmgroup.tdd.groupcontroller;

import java.util.Map;

public class DatabaseReader {
	public Map<String, Trainee> readGroup() {
		return null;
	}
}
