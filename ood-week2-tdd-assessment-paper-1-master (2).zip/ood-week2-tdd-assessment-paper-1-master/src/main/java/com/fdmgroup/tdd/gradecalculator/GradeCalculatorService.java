package com.fdmgroup.tdd.gradecalculator;

public interface GradeCalculatorService {
	public String getClassification(double mark);

}
