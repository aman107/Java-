
public class Snack implements BasketItem, FoodItem  {
	private int fatContent;
	private int sugarContent;
	private String name;
	private int calories;
	private double price;
	
	
	
	public Snack() {
		// TODO Auto-generated constructor stub
	}

	public int getFatContent() {
		return fatContent;
	}
	public void setFatContent(int fatContent) {
		this.fatContent = fatContent;
	}
	public int getSugarContent() {
		return sugarContent;
	}
	public void setSugarContent(int sugarContent) {
		this.sugarContent = sugarContent;
	}

	@Override
	public int getCalories() {
		// TODO Auto-generated method stub
		return calories;
	}

	@Override
	public void setCalories(int calories) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public void setName(String name) {
		this. name =  name;
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return price;
	}

	@Override
	public void setPrice(double price) {
		
		this. price =  price;	
	}

	

}
