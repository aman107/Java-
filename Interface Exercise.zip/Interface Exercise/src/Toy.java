
public class Toy implements BasketItem {
	
	private int minAge;
	private int maxAge;
	private String name;
	private double price;

	public Toy() {
		// TODO Auto-generated constructor stub
	}
	public int getMinAge() {
		return minAge;
	}
	public void setMinAge(int minAge) {
		this.minAge = minAge;
	}
	public int getMaxAge() {
		return maxAge;
	}
	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}



	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}
	@Override
	public void setName(String name) {
		
		this.name = name;
		// TODO Auto-generated method stub
		
	}
	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return price;
	}
	@Override
	public void setPrice(double price) {
		this.name = name;
		// TODO Auto-generated method stub
		
	}
	
	
	

}
