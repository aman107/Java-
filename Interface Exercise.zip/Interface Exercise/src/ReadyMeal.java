
public class ReadyMeal implements BasketItem, FoodItem{
	
	private String cuisineType;


	public ReadyMeal() {
		// TODO Auto-generated constructor stub
	}

	public String getCuisineType() {
		return cuisineType;
	}

	public void setCuisineType(String cuisineType) {
		this.cuisineType = cuisineType;
	}

	

	public int getCalories() {
		// TODO Auto-generated method stub
		return 0;
	}


	public void setCalories(int calories) {
		// TODO Auto-generated method stub
		
	}


	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}


	public void setName(String name) {
		// TODO Auto-generated method stub
		
	}


	public double getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}


	public void setPrice(double price) {
		// TODO Auto-generated method stub
		
	}

}
