
public interface BasketItem {
public abstract String  getName();
public abstract void setName(String name);
public  abstract double getPrice();
public  abstract  void setPrice(double price);
}
