import java.util.ArrayList;
import java.util.List;

public class Basket {
	public ArrayList<Book> books = new ArrayList<>();
	
	public ArrayList<Book> getBooksInBasket() {
		// TODO Auto-generated method stub
		return books;
	}
	public List<Book> addBook(Book book)
	{
		//books.add(book);
		books.add(book);
		return books;
	}

}
;