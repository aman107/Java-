
public class Book {
	private double price;

	public Book() {
		
	}

	public Book(double i, double j) {
		
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
