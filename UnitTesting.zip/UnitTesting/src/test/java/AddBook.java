import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class AddBook {

	@Test
	public void test_GetBooksInBasket_ReturnsArrayOfLengthOne_AfterAddBookMethodIsCalledWithOneBook1() {
		//Book book = new Book();//Arrange
		Basket basket = new Basket();//Arrange
		
		ArrayList<Book> bookList = basket.getBooksInBasket();//act
		
		assertEquals(1,bookList.size());
		
	}
	@Test
	public void test_GetBooksInBasket_ReturnsArrayOfLengthOne_AfterAddBookMethodIsCalledWithOneBook() {
		Book book = new Book(1,10);//Arrange
		Basket basket = new Basket();//Arrange
		
		List<Book>AddedBooks= basket.addBook(book);//act
		
		assertEquals(2,AddedBooks.size());
		
	}

}
