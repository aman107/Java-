import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CheckoutTest {

	@Test
	public void test_CalculatePrice_ReturnsDoubleZeroPointZeroWhenPassedAnEmptyBasket() {
		Basket basket = new Basket();
		Checkout checkout = new Checkout();
		
		 double price= checkout.calculatedPrice(basket);
		 
		 assertEquals(0,price);
		
	}


	@Test
	public void test_CalculatePrice_ReturnsPriceOfBookInBasket_WhenPassedBasketWithOneBook() {
		Basket basket = new Basket();
		Book book = new Book();
		Checkout checkout = new Checkout();
		double expected = 15.0;
		basket.addBook(book);
		checkout.setPrice(expected);
		assertEquals(15.0, checkout.calculatedPrice(basket));
		//test code
	}
	@Test
	public void test_CalculateThePriceWhenTwoBooks_In()
	{
		Basket basket = new Basket();
		Book book = new Book();
		Checkout checkout = new Checkout();
		
		double expected = 20.0;
		 basket.addBook(book);
		 basket.addBook(book);
		 checkout.setPrice(10);
		 assertEquals(20, checkout.calculatedPrice(basket));
	}
	@Test
	public void test_CalculatePrice_ReturnsPriceOfBooksInBasket_WhenPassedBasketWithTwoUniqueBooks() {
		Basket basket = new Basket();
		Checkout checkout = new Checkout();
		Book book1 = new Book(1, 10);
		Book book2 = new Book(2, 20);
		basket.addBook(book1);
		basket.addBook(book2);
		assertEquals(28.5, checkout.calculatedPrice(basket));
		//test code
	}
	@Test	
	public void test_CalculatePrice_ReturnsPriceOfBooksInBasket_WhenPassedBasketWithThreeUniqueBooks() {
		       Basket basket = new Basket();
		     Checkout checkout = new Checkout();
			Book book1 = new Book(1, 25.99);
			Book book2 = new Book(2, 25.99);
			Book book3 = new Book(3, 25.99);
			basket.addBook(book1);
			basket.addBook(book2);
			basket.addBook(book3);
			double total = 73.29;
			assertEquals(total, checkout.calculatedPrice(basket));
			//test code
	}
	@Test	
	public void test_CalculatePrice_ReturnsPriceOfBooksInBasket_WhenPassedBasketWithSevenUniqueBooks() {
		 Basket basket = new Basket();
	     Checkout checkout = new Checkout();
			Book book = new Book();
			for(int i = 1; i <= 7; i++) {
				book = new Book(i, 25.99);
				basket.addBook(book);
				
			}
			double total = 169.19;
			assertEquals(total, checkout.calculatedPrice(basket));
			//test code
	}
	@Test
	public void test_CalculatePrice_ReturnsPriceOfBooksInBasket_WhenPassedBasketWithTwoSameBooks() {
		 Basket basket = new Basket();
	     Checkout checkout = new Checkout();
			Book book = new Book();
		Book book1 = new Book(1, 10);
		Book book2 = new Book(1, 10);
		basket.addBook(book1);
		basket.addBook(book2);
		assertEquals(10, checkout.calculatedPrice(basket));
		//test code
	}
}
