import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

class OneBookPassed {

	@Test
	public void test_CalculatePrice_ReturnsPriceOfBookInBasket_whenPassedBasketWithOneBook() {
		Book book = new Book(1,10);
		Basket basket = new Basket();
		Checkout checkout = new Checkout();
		
		basket.addBook(book);
		
		
		assertEquals(1,basket.getBooksInBasket().size());
		
		
	}
}

