import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

class BasketTest {

	@Test
	public void test_GetBooksInBasket_ReturnsEmptyBookList_IfNoBooksHaveNeenAdded() {
		Basket basket = new Basket();//Arrange
		List<Book>booksInBasket= basket.getBooksInBasket();//Act
		assertEquals(0,booksInBasket.size());//Arrange
	}

}
