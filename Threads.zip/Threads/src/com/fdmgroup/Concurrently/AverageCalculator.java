package com.fdmgroup.Concurrently;


public class AverageCalculator {
	private long total = 0;
	private long count = 0;
	
	public long getTotal() {
		return total;
	}
	public long getCount() {
		return count;
	}
	
	public synchronized void addToTotal (int number) {
		total += number;
		count++;
	}
	
	public double calculateAverage() {
		
		return (double) total/count;
	}
}