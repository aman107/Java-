package com.fdmgroup.Concurrently;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderThread extends Thread {

	private AverageCalculator averageCalculator;
	private String fileName;

	public FileReaderThread(AverageCalculator averageCalculator, String fileName) {
		super();
		this.averageCalculator = averageCalculator;
		this.fileName = fileName;
	}

	@Override
	public void run() {
		try {
			FileReader fReader = new FileReader(fileName);
			BufferedReader bReader = new BufferedReader(fReader);
			String line = "";
			while ((line = bReader.readLine()) != null) {
				String[] splittedLine = line.split(",");

				for (int i = 0; i < splittedLine.length; i++) {
					averageCalculator.addToTotal(Integer.parseInt(splittedLine[i]));
				}
			}

		} catch (FileNotFoundException e) {
			//
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
}