package com.fdmgroup.Concurrently;

public class Runner {

	public static void main(String[] args) {
		AverageCalculator obj = new AverageCalculator();
		String[] fileName = {"C:\\Users\\Amandeep\\Desktop\\hello1.txt"};
		FileReaderThread obj1 = new FileReaderThread(obj, null);
		obj1.start();
	}

}
