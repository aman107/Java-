package com.fdmgroup.threadingExcercises;

public class ThreadManagerChild extends ThreadManager{
	
	public void createThreads(int number) {
		
		
		Thread thread = new Thread(() -> {
		Thread thread1 = new Thread();
		
		Thread thread2 = new Thread();
		thread2.start();
		Thread thread3 = new Thread();
		thread3.start();
		Thread thread4 = new Thread();
		thread4.start();

		threads.add(thread1);
		threads.add(thread2);
		threads.add(thread3);
		threads.add(thread4);
		});thread.start();
}
}
