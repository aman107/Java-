package com.fdmgroup.threadingExcercises;

public class MyRunnable implements Runnable{

	@Override
	public void run() {
		System.out.println("id running");
	}

}
