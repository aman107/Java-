package com.fdmgroup.threadingExcercises;

public class Runner {
public static void main(String[] args) {
	ThreadManager obj2 = new ThreadManager();
	ThreadManagerChild obj3 = new ThreadManagerChild();
	obj3.createThreads(7);
	obj2.createThreads(9);
	obj2.runThreads(1);
}
}
