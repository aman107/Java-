package com.fdmgroup.threadingExcercises;

import java.util.ArrayList;
import java.util.List;

public class ThreadManager {
protected List<Thread> threads = new ArrayList<Thread>();
public void createThreads(int number) {
	
MyRunnable obj1 = new MyRunnable();

Thread thread1 = new Thread(obj1,"thread1");
thread1.start();
Thread thread2 = new Thread(obj1,"thread2");
thread2.start();
Thread thread3 = new Thread(obj1,"thread3");
thread3.start();
Thread thread4 = new Thread(obj1,"thread4");
thread4.start();

threads.add(thread1);
threads.add(thread2);
threads.add(thread3);
threads.add(thread4);
}


void runThreads(int i) {
	for (Thread thread : threads) {
		System.out.println(thread);
	}
}

}
