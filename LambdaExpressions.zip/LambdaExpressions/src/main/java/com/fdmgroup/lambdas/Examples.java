package com.fdmgroup.lambdas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Examples {

	public static void main(String[] args) {
		
		/*Trainee obj2 = new Trainee("Jane","Johns","BA", 3,27,82.0);
		Trainee obj3 = new Trainee("Tom","William","BA", 8,25,25.0);
		Trainee obj4 = new Trainee("Jo","Taylor","Java", 4,20,63.0);
		Trainee obj5 = new Trainee("Pat","Brown","BA", 7,22,94.0);
		Trainee obj6 = new Trainee("Fay","Davies","Java", 2,26,50.0);*/
		
		Function<Trainee,String>getfull= obj1 -> obj1.getFirstName()+""+obj1.getLastName();
		Trainee obj1 = new Trainee("John","Smith","Java", 2,25,75.0);
		String fullname = getfull.apply(obj1);
		System.out.println(fullname );
		
	
	//bIfUNCTION - IT TAKES 2 ARGUMENTS
	
	BiFunction<Trainee, String, String> getTraineeNameWithTitle = (trainee, title) -> title + " "
			+ trainee.getFirstName() + " " + trainee.getLastName();

	Trainee obj11 = new Trainee("John","Smith","Java", 2,25,75.0);
	

	String fullNameWithTitle = getTraineeNameWithTitle.apply(obj11, "title1");
	System.out.println(fullNameWithTitle);

	
	
	//Predicate // it takes single argument and returns boolean
	//auguments->expressions
	Predicate<Trainee> isGradeA = trainee -> trainee.getAverageGrade() > 90;

	Trainee trainee2 =  new Trainee("John","Smith","Java", 2,25,85.0);
	Trainee trainee3 =  new Trainee("John","Smith","Java", 2,25,75.0);
	boolean isGradeAorNot = isGradeA.test(trainee3);
	System.out.println(isGradeAorNot);
	
	
	//BiPredicate
	BiPredicate<Trainee, Trainee> compareMarks = (t1, t2) -> t1.getAverageGrade() > t2.getAverageGrade();
	System.out.println(compareMarks.test(trainee3, trainee2));
	
	//Binary takes two argumens and return a value
	
	BinaryOperator<Trainee> returnGreater = (t1, t2) -> t1.getAverageGrade()  > t2.getAverageGrade()  ? t1 : t2;
	System.out.println(returnGreater.apply(trainee2, trainee3).getFirstName());

	
	//Consumer  takes single argument and does not return anything
	Consumer<Trainee> printFullName = t1 -> System.out.println(t1.getFirstName() + " " + t1.getLastName());
	printFullName.accept(trainee3);
	

	System.out.println();
	List<Trainee> trainees = new ArrayList<>();
	trainees.add(trainee3);
	trainees.add(trainee2);
	
	

	//ForEach
	trainees.forEach(trainee -> System.out.println(trainee.getFirstName() + " " + trainee.getLastName()));

	Comparator<Trainee> traineeStreamComparator = (firstTrainee, secondTrainee) -> firstTrainee.getStream()
			.compareTo(secondTrainee.getStream());
	
	Collections.sort(trainees, traineeStreamComparator);
	trainees.forEach(trainee -> System.out.println(trainee.getFirstName() + " " + trainee.getLastName()));

	Comparator<Trainee> traineeNameComparator = (firstTrainee, secondTrainee) -> firstTrainee.getFirstName()
			.compareTo(secondTrainee.getFirstName());
	
	Collections.sort(trainees, traineeNameComparator);
	trainees.forEach(trainee -> System.out.println(trainee.getFirstName() + " " + trainee.getLastName()));

	System.out.println();//Two Compartotrs Added
	Comparator<Trainee> compareStreamAndName = traineeStreamComparator.thenComparing(traineeNameComparator);
	Collections.sort(trainees, compareStreamAndName);
	trainees.forEach(trainee -> System.out.println(trainee.getFirstName() + " " + trainee.getLastName()));
	}
	
	}


