package com.fdmgroup.lambda.Exercise;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

import com.fdmgroup.lambdas.Trainee;

public class Runner {
	public static void main(String[] args) {
		
	
BankAccount account1= new BankAccount(12345678,987654,"Mr J Smoth","savings", 1.1,25362.91);
BankAccount account2= new BankAccount(87654321	,234567,"	Ms J Jones","	current/checking",	0.2	,550);
BankAccount account3= new BankAccount(74639572,	946284,	"Dr T Williams"	,"savings"	,1.1,	4763.32);
BankAccount account4= new BankAccount(94715453,	987654,	"Ms S Taylor","savings",1.1	,10598.01);
BankAccount account5= new BankAccount(16254385,	234567,	"Mr P Brown","current/checking",	0.2	,-195.74);
BankAccount account6= new BankAccount(38776543,	946284,	"Ms F Davies",	"current/checking",	0.2	,-503.47);
BankAccount account7= new BankAccount(87609802	,987654,	"Mr B Wilson"	,"savings",	1.1,	2.5);
BankAccount account8= new BankAccount(56483769,	234567	,"Dr E Evans",	"current/checking",	0.2,	-947.72);

//1
Function< BankAccount,String > temp1 = BankAccount -> account3.getAccountHolder()+""+account3.getBalance();
String return1 = temp1.apply(account3);
System.out.println(return1);

//2
Function<BankAccount, Double> temp2 = BankAccount -> (account2.getBalance()*account2.getInterestRate())/100;
Double return2 = temp2.apply(account2);
System.out.println(return2);

//3---------------------------------------------------------------------------------------------------------
BiFunction<BankAccount, Boolean,Boolean> temp3= (BankAccount,balance) -> (((account2.getBalance()*account2.getInterestRate())/100))>(account2.getBalance());;
//return6 = temp3.apply(account2, null);
/*
 * BiFunction<Trainee, String, String> getTraineeNameWithTitle = (trainee, title) -> title + " "
			+ trainee.getFirstName() + " " + trainee.getLastName();

	Trainee obj11 = new Trainee("John","Smith","Java", 2,25,75.0);
	

	String fullNameWithTitle = getTraineeNameWithTitle.apply(obj11, "title1");
	System.out.println(fullNameWithTitle);
 */
 
//4
Predicate<BankAccount> isCurrenAccount= BankAccount -> account6.getAccountType().equals("current/checking");
boolean return4 = isCurrenAccount.test(account6);
System.out.println(return4 );

//5--------------------------------------------------------------------------------------------------------
BiPredicate<BankAccount,BankAccount> CheckIfOverdrawn = (t1,t2) -> t1.getBalance()>1.5;
System.out.println(CheckIfOverdrawn.test(account5, account8));
//6
BinaryOperator<BankAccount> return5 = (t1,t2) -> t1.getBalance()>t2.getBalance()?t1:t2;
System.out.println(return5.apply(account3, account4).getBalance());

//7
Consumer<BankAccount> Balance = t1->System.out.println(t1.getBalance()-10);
Balance.accept(account6);
//8------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
BiConsumer<BankAccount,Integer> second = (t1,t2) ->System.out.println(t1.getBalance()-(Integer.MAX_VALUE));
second.accept(account1, (int) 25262.91);


//1.4

ArrayList <BankAccount> bankAccountArrayList2 = new ArrayList<BankAccount>();
bankAccountArrayList2.add(account1);
bankAccountArrayList2.add(account2);
bankAccountArrayList2.add(account3);
bankAccountArrayList2.add(account4);
bankAccountArrayList2.add(account5);
bankAccountArrayList2.add(account6);
bankAccountArrayList2.add(account7);
bankAccountArrayList2.add(account8);

Comparator<BankAccount> bankAccountComparator2 = (firstAccount, secondAccount) -> Double.compare(firstAccount.getBalance(), secondAccount.getBalance()); 
Comparator<BankAccount> bankAccountComparator = (firstAccount, secondAccount) -> firstAccount.getAccountType().compareTo(secondAccount.getAccountType()); 
Comparator<BankAccount> bankAccountComparator3 = (firstAccount, secondAccount) -> ((Integer) firstAccount.getAccountNumber()).compareTo(secondAccount.getAccountNumber()); 
bankAccountArrayList2.sort(bankAccountComparator);
bankAccountArrayList2.sort(bankAccountComparator2);
bankAccountArrayList2.sort(bankAccountComparator3);

for (BankAccount account : bankAccountArrayList2) {
	//System.out.println(account.getBalance());
	//System.out.println(account.getAccountType());
	//System.out.println(account.getAccountNumber());
}

//1.5
ArrayList <BankAccount> BankAccountArrayList2 = new ArrayList<BankAccount>();
bankAccountArrayList2.add(account1);
bankAccountArrayList2.add(account2);
bankAccountArrayList2.add(account3);
bankAccountArrayList2.add(account4);
bankAccountArrayList2.add(account5);
bankAccountArrayList2.add(account6);
bankAccountArrayList2.add(account7);
bankAccountArrayList2.add(account8);


Map<Integer, Integer> bankAccountMap = new HashMap<Integer, Integer>();
Map<Integer, Double> bankAccountMap2 = new HashMap<Integer, Double>();
for (BankAccount account : BankAccountArrayList2) {
	bankAccountMap.merge(account.getBankCode(), 1 , (currentBankCode, one ) -> (bankAccountMap.containsKey(account.getBankCode())) ? bankAccountMap.get(account.getBankCode()) + one : currentBankCode );
}

for (BankAccount account : bankAccountArrayList2) {
	bankAccountMap2.merge(account.getBankCode(), account.getBalance() , (currentBankCode, currentBalance ) -> (bankAccountMap.containsKey(account.getBankCode())) ? bankAccountMap.get(account.getBankCode()) + currentBalance : currentBankCode );
}

//System.out.println(bankAccountMap);

System.out.println(bankAccountMap2);

}
}
