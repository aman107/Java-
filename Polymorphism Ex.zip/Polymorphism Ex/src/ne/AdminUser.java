package ne;

public class AdminUser extends UserAccount {
	private static int minAdminPasswordLength;

	public static int getMinAdminPasswordLength() {
		return minAdminPasswordLength;
	}

	public static void setMinAdminPasswordLength(int minAdminPasswordLength) {
		AdminUser.minAdminPasswordLength = minAdminPasswordLength;
	}

	

	public boolean changePassword(String newPass, String confirmPass) {
		
		if ((newPass == confirmPass) && newPass.length() >= getMinAdminPasswordLength() ) {
			return true;
		} 
		return false;

	}

	public  boolean changePassword(String newPass, String confirmPass, UserAccount user) {
		user.changePassword(newPass, confirmPass);
		return user.changePassword(newPass, confirmPass);
	}

	public AdminUser(String username, String password, String fullName) {
		super(username, password, fullName);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void acessWebsite() {
		System.out.println("accessing website with admin rights");

	}

}
/*else if ((newPass.length()) >= getMinAdminPasswordLength()
&& confirmPass.length() >= getMinAdminPasswordLength())*/