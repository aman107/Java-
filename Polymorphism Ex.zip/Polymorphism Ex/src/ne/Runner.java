package ne;

public class Runner {
	public static void main(String[] args) {
		AdminUser obj1 = new AdminUser("JohnSmith", "John", "pass1");
		AdminUser obj2 = new AdminUser("Marker", "Mark", "pass2");

		AdminUser.setMinAdminPasswordLength(10);

		System.out.println(obj1.changePassword("bcdefghijii", "bcdefghijii"));
		System.out.println(obj1.changePassword("bcdefgh", "bcdefgh"));

		Customer obj3 = new Customer("Turner", "Turn", "Louis");
		System.out.println(obj2.changePassword("Mark", "Mark", obj3));
		 

		Customer obj4 = new Customer("MeeMaw", "Mee", "pass4");
		

		

	}

}
