
public class HardDrive {

}
