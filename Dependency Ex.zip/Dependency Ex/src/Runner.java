import java.util.ArrayList;
import java.util.Arrays;

public class Runner {

	public static void main(String[] args) {

		HardDrive hardrive1 = new HardDrive();
		Memory memory1 = new Memory();
		Processor processor1 = new Processor();

		HardDrive hardrive2 = new HardDrive();
		Memory memory2 = new Memory();
		Processor processor2 = new Processor();

		Computer computer1 = new Computer("Dell", hardrive1, memory1, processor1);
		Computer computer2 = new Computer("Lenovo", hardrive2, memory2, processor2);
		System.out.println(computer1);

		PowerSource obj = new PowerSource();
		obj.setWatts(5.6);
		computer1.getPower(obj);

		ComputerStore compStoreObj = new ComputerStore("best buy");
		compStoreObj.addComputer(computer2);
		compStoreObj.addComputer(computer1);
		ArrayList<Computer> computers = compStoreObj.getAllComputers();

		for (Computer computer : computers) {
			System.out.println(computer);

		}

		// System.out.println(Arrays.);

	}

}
