
public class Memory {

}
