
public class PowerSource {
public double watts;
public double supplyPower() {
	return watts;
}
public double getWatts() {
	return watts;
}
public void setWatts(double watts) {
	this.watts = watts;
}
}
