package classesExercise;

public class HardDrive {
	
private String MODEL ;
private double CAPACITY;
private double usedSpace;


public String readData(String file)
{
	return "read from"+file;
	}
public void writeData(String data, String file)
{
	System.out.println("writeData");
	}
public HardDrive(String mODEL, double cAPACITY) {
	super();
	MODEL = mODEL;
	CAPACITY = cAPACITY;
}
public String getMODEL() {
	return MODEL;
}
public void setMODEL(String mODEL) {
	MODEL = mODEL;
}
public double getCAPACITY() {
	return CAPACITY;
}
public void setCAPACITY(double cAPACITY) {
	CAPACITY = cAPACITY;
}
public double getUsedSpace() {
	return usedSpace;
}
public void setUsedSpace(double usedSpace) {
	this.usedSpace = usedSpace;
}
@Override
public String toString() {
	return "HardDrive [MODEL=" + MODEL + ", CAPACITY=" + CAPACITY + ", usedSpace=" + usedSpace + "]";
}


}
