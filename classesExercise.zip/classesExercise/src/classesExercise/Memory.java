package classesExercise;

public class Memory {
	
private String MODEL ;
private double CAPACITY;
private double usedSpace;
private double speed;


public Memory(String mODEL, double cAPACITY, double speed) {
	super();
	MODEL = mODEL;
	CAPACITY = cAPACITY;
	this.speed = speed;
}
public void storeData(String data)
{
	System.out.println("storeData");
	}
public String getMODEL() {
	return MODEL;
}
public void setMODEL(String mODEL) {
	MODEL = mODEL;
}
public double getCAPACITY() {
	return CAPACITY;
}
public void setCAPACITY(double cAPACITY) {
	CAPACITY = cAPACITY;
}
public double getUsedSpace() {
	return usedSpace;
}
public void setUsedSpace(double usedSpace) {
	this.usedSpace = usedSpace;
}
public double getSpeed() {
	return speed;
}
public void setSpeed(double speed) {
	this.speed = speed;
}
@Override
public String toString() {
	return "Memory [MODEL=" + MODEL + ", CAPACITY=" + CAPACITY + ", usedSpace=" + usedSpace + ", speed=" + speed + "]";
}

}
