package classesExercise;

public class Runner {
	public static void main(String[] args) {
	
	HardDrive obj1 = new HardDrive("Seagate",2);
	HardDrive obj4 = new HardDrive("DELL",3);
	
	obj1.getMODEL();
	obj1.getCAPACITY();
	obj1.getUsedSpace();
	obj1.setUsedSpace(50);
	obj1.getUsedSpace();
	System.out.println(obj1);
    System.out.println(obj4);
	
	Memory obj2 = new Memory("Kingston",4, 1600);
	Memory obj5 = new Memory("cOROSOR",8, 1333);
	obj2.getCAPACITY();
	obj2.getMODEL();
	obj2.getSpeed();
	obj2.getUsedSpace();
	System.out.println(obj2);
	System.out.println(obj5);
	

	Processor obj3 = new Processor("Intel",2.93,6);
	Processor obj6 = new Processor("Intel Cerelon",2.29,2);
	obj3.getMODEL();
	obj3.getSPEED();
	obj3.processData(null);
	obj3.getNUMBER_OF_CORES();
	System.out.println(obj3);
	System.out.println(obj4);
	}
}
