
public class Runner {
	public static void main(String[] args) {
		AdminUser obj1 = new AdminUser("JohnSmith", "John", "pass1");
		AdminUser obj2 = new AdminUser("Marker", "Mark", "pass2");
		
		

		Customer obj3 = new Customer("Turner", "Turn", "pass3");
		Customer obj4 = new Customer("MeeMaw", "Mee", "pass4");

//boolean return1 =obj1.changePassword("John1", "John1");
//System.out.println( return1 );
//boolean return2 = obj1.changePassword("Turner", "Turn");
//System.out.println( return2);

//obj3.acessWebsite();
//obj1.acessWebsite();

		UserAccountManager obj5 = new UserAccountManager();
		obj5.addUser(obj4);
		obj5.addUser(obj1);
		obj5.addUser(obj2);
		obj5.addUser(obj3);

		System.out.println();
		System.out.println(obj5.login("JohnSmith", "John"));
//System.out.println(return4);
//boolean return5=
		System.out.println(obj5.login("John1", "John1hhhhh"));

	}

}
