import java.util.ArrayList;

public class UserAccountManager {
	private ArrayList<UserAccount> userAccounts = new ArrayList<UserAccount>();

	public void addUser(UserAccount user) {

		userAccounts.add(user);
	}

	public boolean login(String username, String password) {

		for (UserAccount item : userAccounts) {
			if (item.getUsername().equals(username) && item.getPassword().equals(password)) {
				
				return true;
			}

		}
		return false;
	}
}
