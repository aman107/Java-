package abc;
import java.util.ArrayList;

public class Runner {

	public static void main(String[] args) {
		
		Toy toy = new Toy();
		toy.setName("Barbie Doll");
		toy.setPrice(35);
		toy.setMinAge(4);
		toy.setMaxAge(13);
		
		
		Laptop laptop = new Laptop();
		laptop.setName("DELL");
		laptop.setMemory(4);
		laptop.setHardDrive(2);
		laptop.setCpuSpeed(4.6);
		laptop.setPrice(3500);
		
		
		Snack snack1 = new Snack();
		Snack snack2 = new Snack();
		
		snack1.setName("Cookies");
		snack1.setCalories(650);
		snack1.setFatContent(150);
		snack1.setSugarContent(60);
		snack1.setPrice(7.50);
	
		snack2.setName("Cracker");
		snack2.setCalories(150);
		snack2.setFatContent(50);
		snack2.setSugarContent(10);
		snack2.setPrice(4.50);
		
		
		ReadyMeal meal1 = new ReadyMeal();	
		ReadyMeal meal2 = new ReadyMeal();		
		
	
		
		meal1.setCuisineType("Italian");
		meal1.setName("Pizza Large");
		meal1.setPrice(25);
		
		meal2.setName("Greek");
		meal2.setName("Salad");
		meal2.setPrice(12);
		meal1.setCalories(700);
		meal2.setCalories(250);
		
		Basket basket = new Basket();
		CalorieCounter calcount = new CalorieCounter();
		ArrayList<FoodItem> lowCalFoods = calcount.getAllLowCalorieFoods();
		for (FoodItem foodItem : lowCalFoods) {
			FoodItem return7=(ReadyMeal)foodItem;//casting

			FoodItem return8=(Snack)foodItem;//casting
			System.out.println(meal1.getCuisineType());
			System.out.println(return8);
		}
		
		
		basket.addItem(toy);
		basket.addItem(laptop);
		basket.addItem(snack1);
		basket.addItem(snack2);
		basket.addItem(meal1);
		basket.addItem(meal2);
		

		ArrayList<BasketItem> basketItems =  basket.getAllItems();
		
		for(BasketItem item : basketItems ) {
			System.out.println(item.getName());
		}
		    
		System.out.println("--------------------------------");
		
		basket.removeItem(meal2);
		
		for(BasketItem item : basketItems ) {
			System.out.println(item.getName());
		}
		System.out.println("--------------------------------");
		
		calcount.addLowCalorieFood(snack1);
		calcount.addLowCalorieFood(snack2);
		calcount.addLowCalorieFood(meal1);
		calcount.addLowCalorieFood(meal2);
		
	//	basket.addLowCalorieFood(toy);
		
	 //ArrayList<FoodItem> lowCalFoods = calcount.getAllLowCalorieFoods() ;
	 
	 for(FoodItem item : lowCalFoods ) {
		 System.out.println(item.getCalories());
	 }
	
		
		
		
		
	}

}
