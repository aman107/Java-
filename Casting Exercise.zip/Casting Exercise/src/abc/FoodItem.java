package abc;

public interface FoodItem {
public abstract int getCalories();
public abstract void setCalories(int calories);
}
