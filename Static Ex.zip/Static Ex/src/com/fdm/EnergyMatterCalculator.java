package com.fdm;

public class EnergyMatterCalculator {
	public static double SPEED_OF_LIGHT = 299792458;
	// public static double energy;
	// public static double matter;

	public static double materToEnergy(double matter) {
		double matter1 = matter / (SPEED_OF_LIGHT * SPEED_OF_LIGHT);
		return matter1;
	}

	public static double energyToMatter(double energy) {
		double energy1 = energy * (SPEED_OF_LIGHT * SPEED_OF_LIGHT);
		return energy1;

	}

}
