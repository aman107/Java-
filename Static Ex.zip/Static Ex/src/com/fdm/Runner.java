package com.fdm;

public class Runner {

	public static void main(String[] args) {
		double return1 =EnergyMatterCalculator.energyToMatter(777777799);
		double return2=EnergyMatterCalculator.materToEnergy(156565998);
		System.out.println(return1);
		System.out.println(return2);
		
		 Employee.setMinimumWage(9.53);
		 
		 Employee obj1 = new Employee();
		 Employee obj2 = new Employee();
		 Employee obj3 = new Employee();
		 
		 obj1.setHourlyWage(4.33);
		 obj2.setHourlyWage(4.23);
		 obj3.setHourlyWage(9.83);
		 
		 double return3 =obj1.getHourlyWage();
		 System.out.println(return3);
		 double return4 =obj2.getHourlyWage();
		 System.out.println(return4);
		 double return5 =obj3.getHourlyWage();
		 System.out.println(return5);
		
	}

}
