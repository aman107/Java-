import java.io.Closeable;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;

public class BufferedReader {

	
	public BufferedReader(FileReader fr) {
		// TODO Auto-generated constructor stub
	}

	public String readLine() {
		// TODO Auto-generated method stub
		return null;
	}

	public void close() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}


