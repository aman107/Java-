import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.text.StyledEditorKit.ForegroundAction;

public class Runner {

	public static void main(String[] args) {
		String returnValue = display1();
		System.out.println(returnValue);
		display(1, "hello", 1.1);
		display(1, 2, 3, 4, 5, 6, 7, 8, 9, 0);
		int returnColourPoints = getPoints("yelow");
		System.out.println(returnColourPoints);
		long returnSum = sumOfNumbersUpTo(46000);
		System.out.println(returnSum);
		boolean returnAcc = validAccountNumber(1000000100);
		System.out.println(returnAcc);
		String Original = reverseString("rebmuN dellac");
		System.out.println(Original);
		int fibonnaci = FibonacciNumber(10);
		{
			System.out.println(fibonnaci);
		}
		displayTimeTable(5);
		printRectangle(4, 8);
		printTriangle(5);
		// boolean returnYear =leapYear(2001);
		// System.out.println(returnYear);
		boolean returnARRAY = arrayContains(args, " ");
		System.out.println(returnARRAY);
		int[] somearray = { 1, 2, 3 };
		int frequency = arrayFrequency(somearray, 4);
		System.out.println(frequency);

		int highNum = maxNumber(somearray);
		System.out.println(highNum);

		int[] extract = { 1, 3, 4, 5 };
		System.out.println(Arrays.toString(extract));
		String[] string1 = { "hi in am in" };
		String[] result = reverseStringArray(string1);
		System.out.println(Arrays.toString(result));

	}

	public static void display() {
		System.out.println("Hi!display is text here");
	}

	@Override
	public String toString() {
		return "Runner [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

	public static void display(int num, String string, double DouValue) {
		System.out.println("values are as folllows" + num + string + DouValue);
	}

	public static void display(int... values) {
		System.out.println("VARAGRS EXAMPLE");
		for (int i : values) {

			System.out.println(i);
		}

	}

	public static String display1() {
		System.out.println("Called");
		return "a value";

	}

	public static int getPoints(String aleignColour)// QUESTION 1.1
	{

		if (aleignColour.equals("green")) {

			return 5;
		} else if (aleignColour.equals("red")) {

			return 6;
		}

		else if (aleignColour.equals("yelow"))

		{
			return 7;
		}
		return 0;

	}

	public static long sumOfNumbersUpTo(int salary) // 1.2

	{

		if (salary > 150000) {
			System.out.println("45%");
			return 2L;
		} else if (salary <= 50000 && salary <= 150000) {
			System.out.println("40%");
			return 3L;
		} else if (salary <= 12500 && salary <= 50000) {
			System.out.println("0%");
			return 4L;
		}
		return salary;
	}

	public static boolean validAccountNumber(int accountNumber)// 1.3
	{
		// int accountNumber = 10000030;
		if (accountNumber >= 10000000 && accountNumber <= 99999999) {
			return true;
		} else {
			return false;
		}
	}

	public static String reverseString(String sentense)// 1.4
	{
		String reversed = "";
		{
			for (int i = sentense.length() - 1; i >= 0; i--)
				reversed += sentense.charAt(i);

		}
		return reversed;

	}

	public static int FibonacciNumber(int number)// 1.5
	{

		int prevousNum = 1;
		int currentNum = 0;

		for (int i = 1; i <= number; i++) {
			int temp = currentNum;
			currentNum += prevousNum;
			prevousNum = temp;

		}

		return currentNum;

	}

	public static void displayTimeTable(int table)// 2.1
	{
		for (int i = 0; i <= 10; i++) {
			System.out.println(i * table);
		}
	}

	/*
	 * public static void printRectangle(int vertical, int horizontal) { for(int
	 * i=1;i<=vertical;i++) { for(int j=1;j<=horizontal;j++) {
	 * System.out.println("x");} } System.out.println(); }
	 */

	public static void printRectangle(int vertical, int horizontal) {// 2.2
		for (int row = 1; row <= vertical; row++) {
			for (int column = 1; column <= horizontal; column++) {
				System.out.print("X");
			}
			System.out.println();
		}
	}

	public static void triangle(int leg) {
		for (int i = 1; i <= leg; i++) {
			System.out.println("X");
		}
	}

	public static void printTriangle(int size) {// 2.3
		for (int row = 1; row <= size; row++) {
			for (int column = 1; column <= row; column++) {
				System.out.print("X");
			}
			System.out.println();
		}
	}

	public static boolean arrayContains(String[] array, String string)// 3.2
	{
		for (String item : array) {
			if (item.contains(string)) {
				return true;
			}
		}
		return false;

	}

	public static int arrayFrequency(int[] somearray, int a) {// 3.3
		int count = 0;
		for (int i : somearray) {
			if (i == a) {
				count++;
			}

		}

		return count;
	}

	public static int maxNumber(int[] array)// 3.4
	{
		Arrays.sort(array);
		int highestIndex = array.length - 1;
		int maximum = array[highestIndex];

		return maximum;

	}

	/*
	 * public static int[] extractEvenArray(int[] array)//3.5 { ArrayList<Integer>
	 * evens = new ArrayList<Integer>(); for (int number : array) { if (number%2==0)
	 * { evens.add(number); }
	 * 
	 * return evens.stream().mapToInt(i->i).toArray(); }
	 */
	public static int[] extractEvenArray(int[] array) {// 3.5

		return Arrays.stream(array).filter(number -> number % 2 == 0).toArray();
	}

	public static String[] reverseStringArray(String[] array) {
		int length = array.length;
		String[] reversed = new String[length];

		for (int index = 0; index < length; index++) {
			int reversedIndex = length - 1 - index;
			reversed[reversedIndex] = array[index];
		}

		return reversed;
	}

}
